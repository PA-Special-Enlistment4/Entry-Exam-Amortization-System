
var queryStringAction = getParameterByName('Action');
var queryStringID = getParameterByName('ID');
var queryStringPropertyUnit = getParameterByName('PropertyUnit');
var querystringStatus = getParameterByName('Status');
var iD = 0;
var status = "";
var draftType = "";
var failed = 0;
var data = [];
var propertyUnit, property, building;



$('#txtRepresentativeTelephoneNo').inputmask('(999) 999-9999')
$('#txtRepresentativeMobileNo').inputmask('(999) 9999999999')


////Date range picker
//$('#reservation').daterangepicker()
////Date picker
//$('#datepicker').datepicker({
//    autoclose: true
//})

//Initialize Select2 Elements
$('.select2').select2()
$('#divDraftType').hide();
Property();
UnitCategory();
Terms();

if (queryStringAction == 'View') {
    ATLCode();
    GetData();
    $('#LessorContractForm').hide();
}
else if (queryStringAction == 'Create') {
    $('#LessorContractListForm').hide();
    $('#divATLCode').hide();
    $('#divStatus').hide();
    $('#btnTerminate').hide();
    $('#btnRenewed').hide();

}
else if (queryStringAction == 'Update') {
    Disabled();
    iD = queryStringID;
    GetData();
}

//Button
$('#btnSearch').click(function () {
    data = [];
    $('#myModalLoad').modal('show');
    var filterStatus = '';

    if ($('#ddlStatus').val() == 'Save') {
        filterStatus = $('#ddlDraftType').val();        
    }
    else {
        filterStatus = $('#ddlStatus').val();
    }

    $.ajax({
        "url": "LessorContract.aspx/GetLessorContract",
        "type": "POST",
        "contentType": "application/json; charset=utf-8",
        "dataType": "json",
        data: JSON.stringify({
            "iD": iD
            , "propertyUnit": $('#ddlPropertyUnit').val()
            , "property": $('#ddlProperty').val()
            , "status": filterStatus
            , "lessorContractCode": $('#ddlATLNo').val()
            , "mode": queryStringAction
            , "unitCategory": ''
        }),
        "success": function (msg) {
            $.each(msg.d, function (i, item) {

                var StartDate = new Date(msg.d[i].ContractStartDate);
                var EndDate = new Date(msg.d[i].ContractEndDate);
                var ModifiedDate = new Date(msg.d[i].ModifiedDate);

                var mm = padLeft(StartDate.getMonth(), 2);
                var yyyy = StartDate.getFullYear();
                var dd = padLeft(StartDate.getDate(), 2);

                var Emm = padLeft(EndDate.getMonth(), 2);
                var Eyyyy = EndDate.getFullYear();
                var Edd = padLeft(EndDate.getDate(), 2);

                data.push([
                         '<div style=" word-wrap: break-word; width: 8em;">' + msg.d[i].PMCode + '</div>'
                            , '<div style=" word-wrap: break-word;width: 8em;">' + msg.d[i].AxcustomerName + '</div>'
                            , '<div style=" word-wrap: break-word;width: 8em;">' + msg.d[i].PropertyUnitAlias + '</div>'
                            , '<div style=" word-wrap: break-word;width: 8em;">' + moment(msg.d[i].ContractStartDate).format('ll') + '</div>'
                            , '<div style=" word-wrap: break-word;width: 8em;">' + moment(msg.d[i].ContractEndDate).format('ll') + '</div>'
                            , '<div style=" word-wrap: break-word;width: 8em;">' + msg.d[i].Status + '</div>'
                            , '<table><tr><td><a href="LessorContract.aspx?Action=Update&ID=' + msg.d[i].PMID + '&Status=' + msg.d[i].Status + '&PropertyUnit=' + msg.d[i].PropertyUnit + '"class="alink"><h3><i class="fa fa-edit"></i></h3> </a></table>']); //</td><td><a href="LessorContract.aspx?Action=Create" class="alink"><h3><i class="fa fa-book"></i></h3></a>


            });

            Table(1);

            $('#myModalLoad').modal('hide');

        }
       ,
        error: function (data) {
            $('#myModalLoad').modal('hide');
        }
    });


});
$('#btnBack').click(function () {
    window.location.replace("LessorContract.aspx?Action=View");
});
$('#btnCreate').click(function () {
    window.location.replace("LessorContract.aspx?Action=Create");
});
$('#btnCancel').click(function () {
    $('#myModalDraft').modal('hide');
});
$('#btnClose').click(function () {
    $('#myModalhistory').modal('hide');
});
$('#btnExport').click(function () {
    window.location.replace("GenerateReport.aspx?propertyUnit=" + propertyUnit);
});

$('#ddlStatus').change(function () {
    var status = $('#ddlStatus').val();
    console.log(status);
    if (status == 'Save') {
        console.log('show');
        $('#divDraftType').show();
    }
    else {
        $('#divDraftType').hide();
    }

});
$('#ddlFilterUnitCategory').change(function () {
    var unitCategoryType = $('#ddlFilterUnitCategory').val();
    if (unitCategoryType == 1) {
        $('#divUnitDressUp').hide();
        $('#divPetRestriction').hide();
    }
    else {
        $('#divUnitDressUp').show();
        $('#divPetRestriction').show();
    }

});
$('#btnEnroll').click(function () {
    $('#myModalLoad').modal('show');
    //$.validator.addMethod('selectFilterPropertyUnit', function (value) {
    //    return (value != '0');
    //}, "");

    //$("#LessorContractForm").validate({
    //    rules: {
    //        filterpropertyunit: {
    //            selectFilterPropertyUnit: true
    //        }
    //    }
    //});

    //if ($("#LessorContractForm").valid()) {
    $.ajax({
        "url": "LessorContract.aspx/GetLessorContract",
        "type": "POST",
        "contentType": "application/json; charset=utf-8",
        "dataType": "json",
        data: JSON.stringify({
            "iD": 0
            , "propertyUnit": $('#ddlFilterPropertyUnit').val()
            , "property": $('#ddlFilterProperty').val()
            , "unitCategory": $('#ddlFilterUnitCategory :selected').text()
            , "status": ''
            , "lessorContractCode": ''
            , "mode": 'Enroll'
        }),
        "success": function (msg) {            
            $.each(msg.d, function (i, item) {
                $('#myModalLoad').modal('hide');
                var birthDate = msg.d[i].BirthDate;
                propertyUnit = msg.d[i].PropertyUnit;
                building = msg.d[i].PropertyTower;
                property = msg.d[i].Property;

                $('#txtProperty').val(msg.d[i].PropertyName);
                $('#txtPropertyTower').val(msg.d[i].BuildingName);
                $('#txtFloor').val(msg.d[i].Floor);
                $('#txtPropertyUnit').val(msg.d[i].PropertyUnitAlias);
                $('#txtUnitCategory').val(msg.d[i].UnitCategory);
                $('#txtUnitType').val(msg.d[i].UnitType);
                $('#txtPaymentStatus').val(msg.d[i].PaymentStatus);
                $('#txtStatus').val(msg.d[i].Status);
                $('#txtFloorArea').val(msg.d[i].FloorArea);
                $('#txtParkingUnit').val(msg.d[i].ParkingUnit);
                $('#txtFloorAreaParking').val(msg.d[i].FloorAreaParking);
                $('#txtCustomerAccount').val(msg.d[i].AxCustomerAccount);
                $('#txtCustomerName').val(msg.d[i].AxcustomerName);
                $('#ddlTerm').val(msg.d[i].LeaseTermDesc);
                $('#txtGender').val(msg.d[i].Gender);
                $('#txtTelephoneNo').val(msg.d[i].TelephoneNo);
                $('#txtMobileNo').val(msg.d[i].MobileNo);
                $('#txtEmailAddress').val(msg.d[i].EmailAddress);
                $('#txtNationality').val(msg.d[i].Nationality);
                $('#txtSpouseName').val(msg.d[i].SpouseName);
                $('#txtCustomerAddress').val(msg.d[i].CustomerAddress);
                $("input[name=maritalstatus][value=" + msg.d[i].MaritalStatus + "]").attr('checked', 'checked');
                $("input[name=residence][value=" + msg.d[i].OwnerShipType + "]").attr('checked', 'checked');


                var pattern = /Date\(([^)]+)\)/;
                var resultsTD = pattern.exec(msg.d[i].BirthDate);
                var dtTD = new Date(parseFloat(resultsTD[1]));

                $("#txtBirthDate").val((dtTD.getMonth() + 1) + "/" + dtTD.getDate() + "/" + dtTD.getFullYear());


            });
            
            History($('#ddlFilterPropertyUnit').val());

        }
       ,
        error: function (data) {
            $('#myModalLoad').modal('hide');
        }
    });


    //}


});
$('#btnSave').click(function () { 
    $("#lblModalAlertBody").text("Are you sure you want to save this computation?");
    $("#divModalAlert #divModalAlertHeaderContainer h4").text("Save");
    $('#myModalAlert').modal({
        backdrop: 'static',
        keyboard: false,
        show: true
    });

});
$('#btnCompute').click(function () {

    $.ajax({
        "url": "Loan.aspx/GetLoan",
        "type": "POST",
        "contentType": "application/json; charset=utf-8",
        "dataType": "json",
        data: JSON.stringify({
            "iD": iD
        }),
        "success": function (msg) {
            $.each(msg.d, function (i, item) {

                var StartDate = new Date(msg.d[i].StartDate);

                data.push([
                    '<div style=" word-wrap: break-word; width: 8em;">' + msg.d[i].SequenceNo + '</div>'
                    , '<div style=" word-wrap: break-word;width: 8em;">' + msg.d[i].PaymentDate + '</div>'
                    , '<div style=" word-wrap: break-word;width: 8em;">' + msg.d[i].LoanAmount + '</div>'
                    , '<div style=" word-wrap: break-word;width: 8em;">' + msg.d[i].MonthlyPayment + '</div>'
                    , '<div style=" word-wrap: break-word;width: 8em;">' + msg.d[i].Balance + '</div>']);

            });

            Table();

            $('#myModalLoad').modal('hide');

        }
        ,
        error: function (data) {
            $('#myModalLoad').modal('hide');
        }
    });
  
});
$('#btnSave').click(function () {
    status = 'Posted';
    ValidateData("Post");
});
$('#btnModalMessageOK').click(function () {
    $('#myModalMessage').modal('hide');  
});
$('#btnModalAlertNo').click(function () {    
    $('#myModalAlert').modal('hide');
});
$('#btnModalAlertYes').click(function () {    
        $.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: 'Loan.apx/Save',
            dataType: "json",
            data: JSON.stringify({
                "Name": $('#txtName').val()
                , "LoanAmount": $('#txtLoanAmount').val()
                , "Interest": $('#Interest').val()
                , "PayableMont": $('#txtPayableMonth').val()
                , "StartDate": $('#txtStartDate').val()               

            }),
            success: function (data) {

                if (data.d != "") {
                    $("#divModalMessage #divModalMessageHeaderContainer h4").text("SAVE");
                    $("#lblModalMessageBody").text("Lessor Contract Sucessfully SAVE.");
                    $('#myModalMessage').modal({
                        backdrop: 'static',
                        keyboard: false,
                        show: true
                    });
                }
                else {
                    $("#divModalMessage #divModalMessageHeaderContainer h4").text("SAVE");
                    $("#lblModalMessageBody").text("SAVE Failed.");
                    $('#myModalMessage').modal({
                        backdrop: 'static',
                        keyboard: false,
                        show: true
                    });                 
                }

            },
            error: function (data) {
                $("#divModalMessage #divModalMessageHeaderContainer h4").text("SAVE");
                $("#lblModalMessageBody").text("SAVE Failed.");
                $('#myModalMessage').modal({
                    backdrop: 'static',
                    keyboard: false,
                    show: true
                });    
            }
        });
    }

});
//-------------------------

//Table 
$('#tblCompute thead  th:not(:eq(6))').each(function () {
    var title = $('#tblCompute thead th:not(:eq(6))').eq($(this).index()).text();
    $(this).html(title + '<br/> <input type="text" style="width:100px;" class="tblComputeInput" placeholder="Search" /> ');
});
///-------------------------

//-------------
function GetData() {

    data = [];
    $('#myModalLoad').modal('show');
        
    $.ajax({
        "url": "Loan.aspx/GetLoan",
        "type": "POST",
        "contentType": "application/json; charset=utf-8",
        "dataType": "json",
        data: JSON.stringify({
            "iD": iD            
        }),
        "success": function (msg) {
            $.each(msg.d, function (i, item) {

                var StartDate = new Date(msg.d[i].StartDate);
                               
                    data.push([
                        '<div style=" word-wrap: break-word; width: 8em;">' + msg.d[i].SequenceNo + '</div>'
                           , '<div style=" word-wrap: break-word;width: 8em;">' + msg.d[i].PaymentDate + '</div>'
                           , '<div style=" word-wrap: break-word;width: 8em;">' + msg.d[i].LoanAmount + '</div>'
                           , '<div style=" word-wrap: break-word;width: 8em;">' + msg.d[i].MonthlyPayment + '</div>'
                           , '<div style=" word-wrap: break-word;width: 8em;">' + msg.d[i].Balance + '</div>']);
                
               });

            Table();

            $('#myModalLoad').modal('hide');

        }
       ,
        error: function (data) {
            $('#myModalLoad').modal('hide');
        }
    });
 }

//-----------------------------
function Table(index) {
  
        tables = $('#tblCompute').DataTable({
            data: data
                  , deferRender: true
                  , destroy: true
                  , processing: true
                , orderCellsTop: true
                  , ordering: true
                   , lengthChange: false
     , sorting: [[4, "desc"]]
        });

    $('.tblComputeInput').val("");
    $('#tblCompute').DataTable().clear();
    $('#tblCompute').DataTable().destroy();

    tables = $('#tblCompute').DataTable({
            data: data
           , deferRender: true
           , destroy: true
           , paging: false
           , orderCellsTop: true
           , ordering: true
           , lengthChange: false
           , sorting: [[4, "desc"]]
        });

    $("#tblCompute thead input").on('keyup change', function () {
            tables
          .column($(this).parent().index() + ':visible')
          .search(this.value)
          .draw();
        });  
}
//----------
function padLeft(data, size, paddingChar) {
    return (new Array(size + 1).join(paddingChar || '0') + String(data)).slice(-size);
}
function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}